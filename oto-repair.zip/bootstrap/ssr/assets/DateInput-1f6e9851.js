import { a as jsx } from "../ssr.js";
import { forwardRef, useRef, useEffect } from "react";
const DateInput = forwardRef(function DateInput2({ type = "date", className = "", isFocused = false, ...props }, ref) {
  const input = ref ? ref : useRef();
  useEffect(() => {
    if (isFocused) {
      input.current.focus();
    }
  }, []);
  return /* @__PURE__ */ jsx(
    "input",
    {
      ...props,
      type,
      className: "border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm " + className,
      ref: input
    }
  );
});
export {
  DateInput as D
};
