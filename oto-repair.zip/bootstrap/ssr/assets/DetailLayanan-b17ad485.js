import { a as jsx, j as jsxs } from "../ssr.js";
import "react";
import { A as Authenticated } from "./AuthenticatedLayout-f0c73b1f.js";
import { Head } from "@inertiajs/react";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "./NavBar-c2f6766d.js";
const Detail = ({ assetPath, layanan }) => {
  const dataLayanan = layanan[0];
  const src = `${assetPath}/${dataLayanan.thumbnail}` || "https://picsum.photos/400";
  return /* @__PURE__ */ jsx("div", { className: "card w-full m-0", children: /* @__PURE__ */ jsxs("div", { className: "card-body py-3", children: [
    /* @__PURE__ */ jsx("div", { className: "flex justify-between", children: /* @__PURE__ */ jsx("h2", { className: "card-title text-3xl mx-auto", children: "Detail layanan" }) }),
    /* @__PURE__ */ jsx("div", { className: "card-detail", children: /* @__PURE__ */ jsx("div", { className: "card bg-base-100 shadow-xl", children: /* @__PURE__ */ jsx("div", { className: "card-body justify-evenly w-7/8", children: /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("div", { className: "avatar flex justify-center", children: /* @__PURE__ */ jsx("div", { className: "w-24 md:w-48 rounded", children: /* @__PURE__ */ jsx("img", { src }) }) }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("div", { className: "text-xl uppercase font-bold", children: dataLayanan.nama_layanan }),
        /* @__PURE__ */ jsx("div", { className: "text-md text-slate-400 uppercase font-bold", children: dataLayanan.kategori })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h2", { className: "card-title text-lg mx-auto", children: "Deskripsi layanan" }),
        /* @__PURE__ */ jsx("table", { className: "table", children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("td", { children: "Tahun" }),
          /* @__PURE__ */ jsx("td", { children: dataLayanan.harga })
        ] }) })
      ] })
    ] }) }) }) })
  ] }) });
};
const DetailKendaraan = ({ auth, assetPath, layanan }) => {
  return /* @__PURE__ */ jsxs(Authenticated, { user: auth.user, children: [
    /* @__PURE__ */ jsx(Head, { title: "Detail Kendaraan" }),
    /* @__PURE__ */ jsx(Detail, { layanan, assetPath })
  ] });
};
export {
  DetailKendaraan as default
};
