import { j as jsxs, a as jsx } from "../ssr.js";
import { Transition } from "@headlessui/react";
import { usePage, useForm, Head } from "@inertiajs/react";
import "react";
import { F as FileInput } from "./FileInput-a502a630.js";
import { T as TextInput, I as InputError } from "./TextInput-6176fc5f.js";
import { I as InputLabel } from "./InputLabel-164e4edc.js";
import { P as PrimaryButton } from "./PrimaryButton-f6376536.js";
import { S as SelectInput } from "./SelectInput-e243adc7.js";
import { A as Authenticated } from "./AuthenticatedLayout-f0c73b1f.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "./NavBar-c2f6766d.js";
const Add = ({ className, bengkels, category = "oli" }) => {
  const user = usePage().props.auth.user;
  const { data, setData, errors, post, processing, recentlySuccessful } = useForm({
    id_bengkel: user.id,
    nama_layanan: "",
    kategori: category.toLowerCase(),
    harga: "",
    thumbnail: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("layanan.store"));
  };
  return /* @__PURE__ */ jsxs("section", { className, children: [
    /* @__PURE__ */ jsx("header", { children: /* @__PURE__ */ jsx("h2", { className: "text-lg font-medium text-gray-900", children: "Tambah Layanan" }) }),
    /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "mt-6 space-y-6", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "id_bengkel", value: "Id Bengkel" }),
        user.role == "admin" && /* @__PURE__ */ jsx(
          SelectInput,
          {
            className: "mt-1 block w-full",
            name: "kategori",
            errors: errors.kategori,
            value: data.kategori,
            onChange: (e) => setData("kategori", e.target.value),
            children: bengkels && bengkels.map((bengkel) => /* @__PURE__ */ jsx("option", { value: bengkel.id, children: bengkel.name }, bengkel.id))
          }
        ),
        user.role !== "admin" && /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "id_bengkel",
            className: "mt-1 block w-full",
            value: data.id_bengkel,
            onChange: (e) => setData("id_bengkel", e.target.value),
            required: true,
            isFocused: true,
            disabled: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.id_bengkel })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "nama_layanan", value: "Nama Layanan" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "nama_layanan",
            className: "mt-1 block w-full",
            value: data.nama_layanan,
            onChange: (e) => setData("nama_layanan", e.target.value),
            required: true,
            isFocused: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.nama_layanan })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "kategori", value: "Kategori" }),
        /* @__PURE__ */ jsxs(
          SelectInput,
          {
            className: "mt-1 block w-full",
            name: "kategori",
            errors: errors.kategori,
            value: data.kategori,
            onChange: (e) => setData("kategori", e.target.value),
            children: [
              /* @__PURE__ */ jsx("option", { value: "oli", children: "Oli" }),
              /* @__PURE__ */ jsx("option", { value: "rem", children: "Rem" }),
              /* @__PURE__ */ jsx("option", { value: "berkala", children: "Berkala" }),
              /* @__PURE__ */ jsx("option", { value: "ban", children: "Ban" }),
              /* @__PURE__ */ jsx("option", { value: "tune up", children: "Tune Up" })
            ]
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.kategori })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "harga", value: "Harga" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "harga",
            className: "mt-1 block w-full",
            value: data.harga,
            onChange: (e) => setData("harga", e.target.value),
            required: true,
            isFocused: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.harga })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "thumbnail", value: "Thumbnail" }),
        /* @__PURE__ */ jsx(
          FileInput,
          {
            className: "mt-1 block w-full",
            name: "thumbnail",
            accept: "image/*",
            errors: errors.thumbnail,
            value: data.thumbnail,
            onChange: (thumbnail) => setData("thumbnail", thumbnail)
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.thumbnail })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsx(PrimaryButton, { disabled: processing, children: "Save" }),
        /* @__PURE__ */ jsx(
          Transition,
          {
            show: recentlySuccessful,
            enter: "transition ease-in-out",
            enterFrom: "opacity-0",
            leave: "transition ease-in-out",
            leaveTo: "opacity-0",
            children: /* @__PURE__ */ jsx("p", { className: "text-sm text-gray-600", children: "Saved." })
          }
        )
      ] })
    ] })
  ] });
};
const TambahKendaraan = ({ auth, bengkels, category }) => {
  return /* @__PURE__ */ jsxs(Authenticated, { user: auth.user, children: [
    /* @__PURE__ */ jsx(Head, { title: "Form Tambah Layanan" }),
    /* @__PURE__ */ jsx(Add, { className: "max-w-xl", user: auth.user, bengkels, category })
  ] });
};
export {
  TambahKendaraan as default
};
