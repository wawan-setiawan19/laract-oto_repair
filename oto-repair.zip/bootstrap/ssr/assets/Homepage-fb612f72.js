import { j as jsxs, a as jsx, F as Fragment } from "../ssr.js";
import "react";
import { Link, Head } from "@inertiajs/react";
import "./NavBar-c2f6766d.js";
import { A as ApplicationLogo } from "./ApplicationLogo-79457c45.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
const Hero = () => {
  return /* @__PURE__ */ jsxs("div", { className: "hero min-h-screen", style: { backgroundImage: "url(https://daisyui.com/images/stock/photo-1507358522600-9f71e620c44e.jpg)" }, children: [
    /* @__PURE__ */ jsx("div", { className: "hero-overlay bg-opacity-60" }),
    /* @__PURE__ */ jsx("div", { className: "hero-content text-center text-neutral-content", children: /* @__PURE__ */ jsxs("div", { className: "max-w-md", children: [
      /* @__PURE__ */ jsx(ApplicationLogo, {}),
      /* @__PURE__ */ jsx("p", { className: "mb-5", children: "Pilihan terbaik untuk mempercayakan servis kendaraan terbak Anda!!" }),
      /* @__PURE__ */ jsx(Link, { href: route("login"), className: "btn btn-warning text-info-content w-full", children: "Login" })
    ] }) })
  ] });
};
const Homepage = (props) => {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: props.title }),
    /* @__PURE__ */ jsx(Hero, {})
  ] });
};
export {
  Homepage as default
};
