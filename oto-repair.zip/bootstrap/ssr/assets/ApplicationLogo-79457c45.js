import { a as jsx, j as jsxs } from "../ssr.js";
function ApplicationLogo(props) {
  return /* @__PURE__ */ jsx("div", { className: "flex justify-center p-3 align-items-center rounded", children: /* @__PURE__ */ jsxs("h1", { className: "text-5xl font-bold text-info-content", children: [
    "Bengkel",
    /* @__PURE__ */ jsx("span", { className: "text-red-800", children: "Go" })
  ] }) });
}
export {
  ApplicationLogo as A
};
