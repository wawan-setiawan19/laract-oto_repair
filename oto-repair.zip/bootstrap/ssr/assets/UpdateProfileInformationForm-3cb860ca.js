import { a as jsx, j as jsxs } from "../ssr.js";
import { T as TextInput, I as InputError } from "./TextInput-6176fc5f.js";
import { I as InputLabel } from "./InputLabel-164e4edc.js";
import { P as PrimaryButton } from "./PrimaryButton-f6376536.js";
import { usePage, useForm, Link } from "@inertiajs/react";
import { Transition } from "@headlessui/react";
import { D as DateInput } from "./DateInput-1f6e9851.js";
import { forwardRef, useRef, useEffect, useState } from "react";
import { S as SelectInput } from "./SelectInput-e243adc7.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
const TextAreaInput = forwardRef(function TextInput2({ type = "text", className = "", isFocused = false, ...props }, ref) {
  const input = ref ? ref : useRef();
  useEffect(() => {
    if (isFocused) {
      input.current.focus();
    }
  }, []);
  return /* @__PURE__ */ jsx(
    "textarea",
    {
      ...props,
      type,
      className: "border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm " + className,
      ref: input
    }
  );
});
function UpdateProfileInformation({ mustVerifyEmail, status, className = "" }) {
  const user = usePage().props.auth.user;
  const { data, setData, put, errors, processing, recentlySuccessful } = useForm({
    name: user.name,
    email: user.email,
    jenis_kelamin: user.jenis_kelamin || "",
    provinsi: user.provinsi || "",
    kota: user.kota || "",
    kecamatan: user.kecamatan || "",
    alamat: user.alamat || "",
    tanggal_lahir: user.tanggal_lahir || ""
  });
  const [provinces, setProvinces] = useState("");
  const [districts, setDistricts] = useState("");
  const [subDistricts, setSubDistricts] = useState("");
  useEffect(() => {
    fetchProvinces();
  }, []);
  useEffect(() => {
    fetchDistricts(data.provinsi);
  }, [data.provinsi]);
  useEffect(() => {
    fetchSubDistricts(data.kota);
  }, [data.kota]);
  const fetchProvinces = async () => {
    try {
      const response = await axios.get("http://dev.farizdotid.com/api/daerahindonesia/provinsi");
      const data2 = response.data.provinsi;
      const sortData = data2.sort((a, b) => a.nama.localeCompare(b.nama));
      setProvinces(sortData);
    } catch (error) {
      console.error("Error fetching provinces:", error);
    }
  };
  const fetchDistricts = async (id) => {
    try {
      const response = await axios.get(`http://dev.farizdotid.com/api/daerahindonesia/kota?id_provinsi=${id}`);
      const data2 = response.data.kota_kabupaten;
      const sortData = data2.sort((a, b) => a.nama.localeCompare(b.nama));
      setDistricts(sortData);
    } catch (error) {
      console.error("Error fetching districts:", error);
    }
  };
  const fetchSubDistricts = async (id) => {
    try {
      const response = await axios.get(`http://dev.farizdotid.com/api/daerahindonesia/kecamatan?id_kota=${id}`);
      const data2 = response.data.kecamatan;
      const sortData = data2.sort((a, b) => a.nama.localeCompare(b.nama));
      setSubDistricts(sortData);
    } catch (error) {
      console.error("Error fetching districts:", error);
    }
  };
  const submit = (e) => {
    e.preventDefault();
    put(route("profile.update"));
  };
  return /* @__PURE__ */ jsxs("section", { className, children: [
    /* @__PURE__ */ jsxs("header", { children: [
      /* @__PURE__ */ jsx("h2", { className: "text-lg font-medium text-gray-900", children: "Profile Information" }),
      /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-gray-600", children: "Update your account's profile information and email address." })
    ] }),
    /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "mt-6 space-y-6", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "name", value: "Name" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "name",
            className: "mt-1 block w-full",
            value: data.name,
            onChange: (e) => setData("name", e.target.value),
            required: true,
            isFocused: true,
            autoComplete: "name"
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.name })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "jenis_kelamin", value: "Jenis Kelamin" }),
        /* @__PURE__ */ jsxs(
          SelectInput,
          {
            className: "mt-1 block w-full",
            name: "jenis_kelamin",
            errors: errors.jenis_kelamin,
            value: data.jenis_kelamin,
            onChange: (e) => setData("jenis_kelamin", e.target.value),
            children: [
              /* @__PURE__ */ jsx("option", { value: "Laki-laki", children: "Laki-laki" }),
              /* @__PURE__ */ jsx("option", { value: "Perempuan", children: "Perempuan" })
            ]
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.name })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "email", value: "Email" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "email",
            type: "email",
            className: "mt-1 block w-full",
            value: data.email,
            onChange: (e) => setData("email", e.target.value),
            required: true,
            autoComplete: "username"
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.email })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "tanggal_lahir", value: "Tanggal Lahir" }),
        /* @__PURE__ */ jsx(
          DateInput,
          {
            id: "tanggal_lahir",
            type: "date",
            className: "mt-1 block w-full",
            value: data.tanggal_lahir,
            onChange: (e) => setData("tanggal_lahir", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.tanggal_lahir })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "provinsi", value: "Provinsi" }),
        /* @__PURE__ */ jsxs(
          SelectInput,
          {
            className: "mt-1 block w-full",
            name: "provinsi",
            errors: errors.provinsi,
            value: data.provinsi,
            onChange: (e) => setData("provinsi", e.target.value),
            children: [
              /* @__PURE__ */ jsx("option", { value: "", children: "Pilih Provinsi" }),
              provinces && provinces.map((province) => /* @__PURE__ */ jsx("option", { value: province.id, children: province.nama }, province.id))
            ]
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.provinsi })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "kota", value: "Kota/Kabupaten" }),
        /* @__PURE__ */ jsxs(
          SelectInput,
          {
            className: "mt-1 block w-full",
            name: "kota",
            errors: errors.kota,
            value: data.kota,
            onChange: (e) => setData("kota", e.target.value),
            children: [
              /* @__PURE__ */ jsx("option", { value: "", children: "Pilih Kabupaten/Kota" }),
              districts && districts.map((district) => /* @__PURE__ */ jsx("option", { value: district.id, children: district.nama }, district.id))
            ]
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.kota })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "kecamatan", value: "Kecamatan" }),
        /* @__PURE__ */ jsxs(
          SelectInput,
          {
            className: "mt-1 block w-full",
            name: "kecamatan",
            errors: errors.kecamatan,
            value: data.kecamatan,
            onChange: (e) => setData("kecamatan", e.target.value),
            children: [
              /* @__PURE__ */ jsx("option", { value: "", children: "Pilih Kecamatan" }),
              subDistricts && subDistricts.map((subDistrict) => /* @__PURE__ */ jsx("option", { value: subDistrict.id, children: subDistrict.nama }, subDistrict.id))
            ]
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.kota })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "alamat", value: "Alamat" }),
        /* @__PURE__ */ jsx(
          TextAreaInput,
          {
            id: "alamat",
            className: "mt-1 block w-full",
            value: data.alamat,
            onChange: (e) => setData("alamat", e.target.value),
            autoComplete: "username"
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.alamat })
      ] }),
      mustVerifyEmail && user.email_verified_at === null && /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs("p", { className: "text-sm mt-2 text-gray-800", children: [
          "Your email address is unverified.",
          /* @__PURE__ */ jsx(
            Link,
            {
              href: route("verification.send"),
              method: "post",
              as: "button",
              className: "underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500",
              children: "Click here to re-send the verification email."
            }
          )
        ] }),
        status === "verification-link-sent" && /* @__PURE__ */ jsx("div", { className: "mt-2 font-medium text-sm text-green-600", children: "A new verification link has been sent to your email address." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsx(PrimaryButton, { disabled: processing, children: "Save" }),
        /* @__PURE__ */ jsx(
          Transition,
          {
            show: recentlySuccessful,
            enter: "transition ease-in-out",
            enterFrom: "opacity-0",
            leave: "transition ease-in-out",
            leaveTo: "opacity-0",
            children: /* @__PURE__ */ jsx("p", { className: "text-sm text-gray-600", children: "Saved." })
          }
        )
      ] })
    ] })
  ] });
}
export {
  UpdateProfileInformation as default
};
