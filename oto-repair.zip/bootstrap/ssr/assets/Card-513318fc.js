import { a as jsx, F as Fragment, j as jsxs } from "../ssr.js";
import { Link } from "@inertiajs/react";
import { useState } from "react";
const Card = ({ layanan, assetPath, konfirmasi }) => {
  const src = `${assetPath}/${layanan.thumbnail}` || "https://picsum.photos/400";
  useState(false);
  useState(null);
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx("div", { className: "card w-full md:w-1/2 md:w-1/3", children: /* @__PURE__ */ jsx("div", { className: "card-body", children: /* @__PURE__ */ jsxs("div", { className: "card-detail", children: [
    /* @__PURE__ */ jsx("div", { className: "card bg-base-100 shadow-xl", children: /* @__PURE__ */ jsxs("div", { className: "card-body justify-evenly w-7/8", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "text-xl uppercase font-bold", children: layanan.nama_layanan }),
          /* @__PURE__ */ jsx("div", { className: "text-md text-slate-400 uppercase font-bold", children: layanan.kategori }),
          /* @__PURE__ */ jsxs("div", { className: "text-md text-slate-400 font-bold", children: [
            "Rp. ",
            layanan.harga
          ] }),
          /* @__PURE__ */ jsx("div", { className: "text-sm text-slate-400 font-bold", children: layanan.name })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "avatar", children: /* @__PURE__ */ jsx("div", { className: "w-24 md:w-48 rounded", children: /* @__PURE__ */ jsx("img", { src }) }) })
      ] }),
      !konfirmasi && /* @__PURE__ */ jsx("div", { className: "card-actions w-full justify-center", children: /* @__PURE__ */ jsx(Link, { href: route("order.show", layanan.id), className: "w-full btn btn-outline btn-primary", children: "Order Layanan" }) })
    ] }) }),
    /* @__PURE__ */ jsx("div", {})
  ] }) }) }) });
};
export {
  Card as C
};
