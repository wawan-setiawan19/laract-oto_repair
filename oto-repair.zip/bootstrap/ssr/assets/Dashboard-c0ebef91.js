import { j as jsxs, a as jsx } from "../ssr.js";
import "react";
import { A as Authenticated } from "./AuthenticatedLayout-f0c73b1f.js";
import { Head } from "@inertiajs/react";
import VisualisasiData from "./VisualisasiData-dd48f9e4.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "./NavBar-c2f6766d.js";
import "./PieChartComponent-55de6194.js";
import "react-chartjs-2";
import "chart.js";
import "html2canvas";
import "jspdf";
const Dashboard = ({ auth, dataLayanan }) => {
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 leading-tight", children: "Dashboard" }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Dasboard Admin" }),
        /* @__PURE__ */ jsx(VisualisasiData, { dataLayanan })
      ]
    }
  );
};
export {
  Dashboard as default
};
