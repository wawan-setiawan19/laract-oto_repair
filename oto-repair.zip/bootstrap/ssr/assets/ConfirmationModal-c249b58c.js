import { a as jsx, j as jsxs } from "../ssr.js";
import "react";
import { D as DangerButton } from "./DangerButton-417c4c8c.js";
const ConfirmationModal = ({ isOpen, onCancel, onConfirmation, data }) => {
  if (!isOpen)
    return null;
  const open = isOpen ? "modal modal-open" : "modal";
  return /* @__PURE__ */ jsx("dialog", { id: "my_modal_1", className: open, children: /* @__PURE__ */ jsxs("form", { method: "dialog", className: "modal-box", children: [
    /* @__PURE__ */ jsx("h3", { className: "font-bold text-lg", children: "Konfirmasi Hapus Data!" }),
    /* @__PURE__ */ jsxs("p", { className: "py-4", children: [
      "Anda yakin ingin menghapus ",
      data,
      "?"
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "modal-action", children: [
      /* @__PURE__ */ jsx("button", { className: "btn", onClick: onCancel, children: "Close" }),
      /* @__PURE__ */ jsx(DangerButton, { className: "btn", onClick: onConfirmation, children: "Delete" })
    ] })
  ] }) });
};
export {
  ConfirmationModal as C
};
