import { j as jsxs, a as jsx } from "../ssr.js";
import { A as Authenticated } from "./AuthenticatedLayout-f0c73b1f.js";
import { useForm, Head, router } from "@inertiajs/react";
import "react";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "./NavBar-c2f6766d.js";
const List = ({ auth, transaksis }) => {
  const { data, setData, errors, post, processing, recentlySuccessful } = useForm({
    id: 1,
    status_pembayaran: "",
    _method: "put"
  });
  const handleSuccess = (e, id) => {
    e.preventDefault();
    alert("pembayaran sukses");
    router.visit(route("transaksi.update", id), {
      method: "put",
      data: {
        status_pembayaran: "done"
      }
    });
  };
  const handlePayment = (e, snapToken, id) => {
    console.log(snapToken);
    window.snap.pay(snapToken, {
      onSuccess: function(result) {
        setData("id", id);
        setData("status_pemabayaran", "done");
        handleSuccess(e, id);
      },
      onPending: function(result) {
        alert("wating your payment!");
        console.log(result);
      },
      onError: function(result) {
        alert("payment failed!");
        console.log(result);
      },
      onClose: function() {
        alert("you closed the popup without finishing the payment");
      }
    });
  };
  return /* @__PURE__ */ jsxs(Authenticated, { user: auth.user, children: [
    /* @__PURE__ */ jsx(Head, { title: "Transaksi Saya" }),
    /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "table table-zebra", children: [
      /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsx("th", {}),
        /* @__PURE__ */ jsx("th", { children: "Nama Layanan" }),
        /* @__PURE__ */ jsx("th", { children: "Kategori" }),
        /* @__PURE__ */ jsx("th", { children: "Tanggal Transaksi" }),
        /* @__PURE__ */ jsx("th", { children: "Metode Pembayaran" }),
        /* @__PURE__ */ jsx("th", { children: "Aksi" })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { children: transaksis && transaksis.map((transaksi, index) => {
        return /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("td", { children: index + 1 }),
          /* @__PURE__ */ jsx("td", { children: transaksi.nama_layanan }),
          /* @__PURE__ */ jsx("td", { children: transaksi.kategori }),
          /* @__PURE__ */ jsx("td", { children: transaksi.tanggal_transaksi }),
          /* @__PURE__ */ jsx("td", { children: transaksi.metode_pembayaran }),
          /* @__PURE__ */ jsx("td", { children: transaksi.status_pembayaran !== "done" && /* @__PURE__ */ jsx("button", { className: "btn btn-primary", onClick: (e) => handlePayment(e, transaksi.snap_token, transaksi.id), children: "Bayar Sekarang" }) })
        ] }, index);
      }) })
    ] }) })
  ] });
};
export {
  List as default
};
