import { a as jsx } from "../ssr.js";
import "./PieChartComponent-55de6194.js";
import "react";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react";
import "@inertiajs/react/server";
import "react-chartjs-2";
import "chart.js";
const Report = ({ auth, dataLayanan, bengkels }) => {
  return /* @__PURE__ */ jsx("div", { children: "TES" });
};
export {
  Report as default
};
