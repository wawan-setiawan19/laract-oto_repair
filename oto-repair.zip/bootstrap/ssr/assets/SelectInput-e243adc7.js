import { a as jsx } from "../ssr.js";
import "react";
const SelectInput = ({
  label,
  name,
  className,
  children,
  errors = [],
  ...props
}) => {
  return /* @__PURE__ */ jsx(
    "select",
    {
      id: name,
      name,
      ...props,
      className: "border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm " + className,
      children
    }
  );
};
export {
  SelectInput as S
};
