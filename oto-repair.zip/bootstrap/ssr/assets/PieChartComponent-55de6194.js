import { a as jsx } from "../ssr.js";
import "react";
import { Bar, Pie } from "react-chartjs-2";
import { Chart, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement } from "chart.js";
Chart.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);
const BarChartComponent = ({ label, value, title }) => {
  const dataOlah = {
    labels: label,
    datasets: [
      {
        label: title,
        data: value,
        backgroundColor: [
          "rgba(255, 99, 132, 0.2)"
        ],
        borderWidth: 1
      }
    ]
  };
  return /* @__PURE__ */ jsx(Bar, { data: dataOlah });
};
Chart.register(ArcElement, Tooltip, Legend);
const PieChartComponent = ({ label, value, title }) => {
  const dataOlah = {
    labels: label,
    datasets: [
      {
        label: title,
        data: value,
        backgroundColor: [
          "rgba(255, 99, 132, 0.2)",
          "rgba(54, 162, 235, 0.2)",
          "rgba(255, 206, 86, 0.2)",
          "rgba(75, 192, 192, 0.2)",
          "rgba(153, 102, 255, 0.2)",
          "rgba(255, 159, 64, 0.2)"
        ],
        borderWidth: 1
      }
    ]
  };
  return /* @__PURE__ */ jsx(Pie, { data: dataOlah });
};
export {
  BarChartComponent as B,
  PieChartComponent as P
};
