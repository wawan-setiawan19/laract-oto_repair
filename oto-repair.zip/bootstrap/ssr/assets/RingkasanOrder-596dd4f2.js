import { j as jsxs, a as jsx } from "../ssr.js";
import { Transition } from "@headlessui/react";
import { useForm, Head } from "@inertiajs/react";
import "react";
import { D as DateInput } from "./DateInput-1f6e9851.js";
import { T as TextInput, I as InputError } from "./TextInput-6176fc5f.js";
import { I as InputLabel } from "./InputLabel-164e4edc.js";
import { P as PrimaryButton } from "./PrimaryButton-f6376536.js";
import { S as SelectInput } from "./SelectInput-e243adc7.js";
import { C as Card } from "./Card-513318fc.js";
import { A as Authenticated } from "./AuthenticatedLayout-f0c73b1f.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "./NavBar-c2f6766d.js";
const Konfirmasi = ({ className, user, layanan, assetPath }) => {
  const date = /* @__PURE__ */ new Date();
  const month = date.getMonth() + 1 < 10 ? `0${date.getMonth() + 1}` : date.getMonth() + 1;
  const currentDate = `${date.getFullYear()}-${month}-${date.getDate()}`;
  const { data, setData, errors, post, processing, recentlySuccessful } = useForm({
    id_bengkel: layanan[0].id_bengkel,
    id_user: user.id,
    id_layanan: layanan[0].id,
    kategori: layanan[0].kategori,
    nama_layanan: layanan[0].nama_layanan,
    metode_pembayaran: "Tunai",
    status_pembayaran: "done",
    harga: layanan[0].harga,
    tanggal_transaksi: currentDate
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("order.store"));
  };
  return /* @__PURE__ */ jsxs("section", { className, children: [
    /* @__PURE__ */ jsx("header", { children: /* @__PURE__ */ jsx("h2", { className: "text-lg font-medium text-gray-900", children: "Konfirmasi Layanan" }) }),
    /* @__PURE__ */ jsx(Card, { assetPath, layanan: layanan[0], konfirmasi: true }),
    /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "mt-6 space-y-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "hidden", children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "id_bengkel", value: "Id Bengkel" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "id_bengkel",
            className: "mt-1 block w-full",
            onChange: (e) => setData("id_bengkel", e.target.value),
            required: true,
            isFocused: true,
            disabled: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.id_bengkel })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "hidden", children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "id_layanan", value: "Id Bengkel" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "id_layanan",
            className: "mt-1 block w-full",
            onChange: (e) => setData("id_layanan", e.target.value),
            required: true,
            isFocused: true,
            disabled: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.id_layanan })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "hidden", children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "harga", value: "Harga" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "harga",
            className: "mt-1 block w-full",
            onChange: (e) => setData("harga", e.target.value),
            required: true,
            isFocused: true,
            disabled: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.harga })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "hidden", children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "tanggal_transaksi", value: "Tanggal Lahir" }),
        /* @__PURE__ */ jsx(
          DateInput,
          {
            id: "tanggal_transaksi",
            type: "date",
            className: "mt-1 block w-full",
            value: data.tanggal_transaksi,
            onChange: (e) => setData("tanggal_transaksi", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.tanggal_transaksi })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "hidden", children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "id_user", value: "ID User" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "id_user",
            className: "mt-1 block w-full",
            value: data.id_user,
            onChange: (e) => setData("id_user", e.target.value),
            required: true,
            isFocused: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.id_user })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "hidden", children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "status_pembayaran", value: "ID User" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "status_pembayaran",
            className: "mt-1 block w-full",
            value: data.status_pembayaran,
            onChange: (e) => setData("status_pembayaran", e.target.value),
            required: true,
            isFocused: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.status_pembayaran })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "hidden", children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "kategori", value: "Kategori" }),
        /* @__PURE__ */ jsxs(
          SelectInput,
          {
            className: "mt-1 block w-full",
            name: "kategori",
            errors: errors.kategori,
            value: data.kategori,
            onChange: (e) => setData("kategori", e.target.value),
            children: [
              /* @__PURE__ */ jsx("option", { value: "Oli", children: "Oli" }),
              /* @__PURE__ */ jsx("option", { value: "Rem", children: "Rem" }),
              /* @__PURE__ */ jsx("option", { value: "Berkala", children: "Berkala" }),
              /* @__PURE__ */ jsx("option", { value: "Ban", children: "Ban" }),
              /* @__PURE__ */ jsx("option", { value: "Tune Up", children: "Tune Up" })
            ]
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.kategori })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "", children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "metode_pembayaran", value: "Metode Pembayaran" }),
        /* @__PURE__ */ jsxs(
          SelectInput,
          {
            className: "mt-1 block w-full",
            name: "metode_pembayaran",
            errors: errors.metode_pembayaran,
            value: data.metode_pembayaran,
            onChange: (e) => setData("metode_pembayaran", e.target.value),
            children: [
              /* @__PURE__ */ jsx("option", { value: "Non-Tunai", children: "Non-Tunai" }),
              /* @__PURE__ */ jsx("option", { value: "Tunai", children: "Tunai" })
            ]
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.metode_pembayaran })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "hidden", children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "nama_layanan", value: "nama_layanan" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "nama_layanan",
            className: "mt-1 block w-full",
            value: data.nama_layanan,
            onChange: (e) => setData("nama_layanan", e.target.value),
            required: true,
            isFocused: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.nama_layanan })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsx(PrimaryButton, { disabled: processing, children: "Bayar Sekarang" }),
        /* @__PURE__ */ jsx(
          Transition,
          {
            show: recentlySuccessful,
            enter: "transition ease-in-out",
            enterFrom: "opacity-0",
            leave: "transition ease-in-out",
            leaveTo: "opacity-0",
            children: /* @__PURE__ */ jsx("p", { className: "text-sm text-gray-600", children: "Saved." })
          }
        )
      ] })
    ] })
  ] });
};
const RingkasanOrder = ({ auth, layanan, assetPath }) => {
  return /* @__PURE__ */ jsxs(Authenticated, { user: auth.user, children: [
    /* @__PURE__ */ jsx(Head, { title: "Ringkasan" }),
    /* @__PURE__ */ jsx(Konfirmasi, { user: auth.user, layanan, assetPath })
  ] });
};
export {
  RingkasanOrder as default
};
