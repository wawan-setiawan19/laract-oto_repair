import { j as jsxs, a as jsx } from "../ssr.js";
import { Transition } from "@headlessui/react";
import { usePage, useForm, Head } from "@inertiajs/react";
import "react";
import { F as FileInput } from "./FileInput-a502a630.js";
import { T as TextInput, I as InputError } from "./TextInput-6176fc5f.js";
import { I as InputLabel } from "./InputLabel-164e4edc.js";
import { P as PrimaryButton } from "./PrimaryButton-f6376536.js";
import { S as SelectInput } from "./SelectInput-e243adc7.js";
import { A as Authenticated } from "./AuthenticatedLayout-f0c73b1f.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "./NavBar-c2f6766d.js";
const Add = ({ className }) => {
  const user = usePage().props.auth.user;
  const { data, setData, errors, post, processing, recentlySuccessful } = useForm({
    id_pemilik: user.id,
    merk: "",
    tipe: "",
    tahun: "",
    bahan_bakar: "Bensin",
    transmisi: "Automatic",
    nopol: "",
    picture: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("kendaraan.store"));
  };
  return /* @__PURE__ */ jsxs("section", { className, children: [
    /* @__PURE__ */ jsx("header", { children: /* @__PURE__ */ jsx("h2", { className: "text-lg font-medium text-gray-900", children: "Tambah Kendaraan" }) }),
    /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "mt-6 space-y-6", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "id_pemilik", value: "Id Pemilik" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "id_pemilik",
            className: "mt-1 block w-full",
            value: data.id_pemilik,
            onChange: (e) => setData("id_pemilik", e.target.value),
            required: true,
            isFocused: true,
            disabled: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.id_pemilik })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "merk", value: "Merk" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "merk",
            className: "mt-1 block w-full",
            value: data.merk,
            onChange: (e) => setData("merk", e.target.value),
            required: true,
            isFocused: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.merk })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "tipe", value: "Tipe" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "tipe",
            className: "mt-1 block w-full",
            value: data.tipe,
            onChange: (e) => setData("tipe", e.target.value),
            required: true,
            isFocused: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.tipe })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "tahun", value: "Tahun" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "tahun",
            className: "mt-1 block w-full",
            value: data.tahun,
            onChange: (e) => setData("tahun", e.target.value),
            required: true,
            isFocused: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.tahun })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "bahan_bakar", value: "Bahan Bakar" }),
        /* @__PURE__ */ jsxs(
          SelectInput,
          {
            className: "mt-1 block w-full",
            name: "bahan_bakar",
            errors: errors.bahan_bakar,
            value: data.bahan_bakar,
            onChange: (e) => setData("bahan_bakar", e.target.value),
            children: [
              /* @__PURE__ */ jsx("option", { value: "Bensin", children: "Bensin" }),
              /* @__PURE__ */ jsx("option", { value: "Diesel", children: "Diesel" })
            ]
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.bahan_bakar })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "transmisi", value: "Transmisi" }),
        /* @__PURE__ */ jsxs(
          SelectInput,
          {
            className: "mt-1 block w-full",
            name: "transmisi",
            errors: errors.transmisi,
            value: data.transmisi,
            onChange: (e) => setData("transmisi", e.target.value),
            children: [
              /* @__PURE__ */ jsx("option", { value: "Automatic", children: "Automatic" }),
              /* @__PURE__ */ jsx("option", { value: "Manual", children: "Manual" })
            ]
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.transmisi })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "nopol", value: "No Polisi" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "nopol",
            className: "mt-1 block w-full",
            value: data.nopol,
            onChange: (e) => setData("nopol", e.target.value),
            required: true,
            isFocused: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.nopol })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "picture", value: "Gambar Mobil" }),
        /* @__PURE__ */ jsx(
          FileInput,
          {
            className: "mt-1 block w-full",
            name: "picture",
            accept: "image/*",
            errors: errors.picture,
            value: data.picture,
            onChange: (picture) => setData("picture", picture)
          }
        ),
        /* @__PURE__ */ jsx(InputError, { className: "mt-2", message: errors.picture })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsx(PrimaryButton, { disabled: processing, children: "Save" }),
        /* @__PURE__ */ jsx(
          Transition,
          {
            show: recentlySuccessful,
            enter: "transition ease-in-out",
            enterFrom: "opacity-0",
            leave: "transition ease-in-out",
            leaveTo: "opacity-0",
            children: /* @__PURE__ */ jsx("p", { className: "text-sm text-gray-600", children: "Saved." })
          }
        )
      ] })
    ] })
  ] });
};
const TambahKendaraan = ({ auth }) => {
  return /* @__PURE__ */ jsxs(Authenticated, { user: auth.user, children: [
    /* @__PURE__ */ jsx(Head, { title: "Form Tambah Kendaraan" }),
    /* @__PURE__ */ jsx(Add, { className: "max-w-xl", user: auth.user })
  ] });
};
export {
  TambahKendaraan as default
};
