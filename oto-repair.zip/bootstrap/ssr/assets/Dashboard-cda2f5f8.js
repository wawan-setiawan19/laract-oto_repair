import { j as jsxs, a as jsx } from "../ssr.js";
import { P as PieChartComponent, B as BarChartComponent } from "./PieChartComponent-55de6194.js";
import "@inertiajs/react";
import { A as Authenticated } from "./AuthenticatedLayout-f0c73b1f.js";
import "react";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "react-chartjs-2";
import "chart.js";
import "./NavBar-c2f6766d.js";
const Dashboard = ({ auth, dataLayanan, bengkels }) => {
  const label = dataLayanan.map((data) => data.kategori);
  const value = dataLayanan.map((data) => data.count);
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 leading-tight", children: "Dashboard" }),
      children: [
        /* @__PURE__ */ jsx("div", { className: "card-actions w-full justify-center align-bottom", children: /* @__PURE__ */ jsx("a", { href: route("bengkel.export"), target: "_blank", children: "Cetak Pdf" }) }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap", children: [
          /* @__PURE__ */ jsxs("div", { className: "card w-full md:w-1/2 lg:w-1/3", children: [
            /* @__PURE__ */ jsx("h2", { className: "card-title text-2xl w-2/3", children: "Layanan yang dimiliki" }),
            /* @__PURE__ */ jsx(PieChartComponent, { label, value, title: "Layanan yang dimiliki" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "card w-full md:w-1/2 lg:w-1/3", children: [
            /* @__PURE__ */ jsx("h2", { className: "card-title text-2xl w-2/3", children: "Layanan yang dimiliki" }),
            /* @__PURE__ */ jsx(BarChartComponent, { label, value, data: dataLayanan, title: "Layanan yang dimiliki" })
          ] })
        ] })
      ]
    }
  );
};
export {
  Dashboard as default
};
