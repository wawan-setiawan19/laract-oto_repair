import { j as jsxs, a as jsx, F as Fragment } from "../ssr.js";
import { Link, Head } from "@inertiajs/react";
import "react";
import { L as Logout } from "./NavBar-c2f6766d.js";
import { A as Authenticated } from "./AuthenticatedLayout-f0c73b1f.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
const HeroAkun = ({ user, percentage }) => {
  return /* @__PURE__ */ jsxs("div", { className: "hero-content flex-row align-top justify-start lg:flex-row", children: [
    /* @__PURE__ */ jsx("div", { className: "avatar", children: /* @__PURE__ */ jsx("div", { className: "w-24 rounded-full", children: /* @__PURE__ */ jsx("img", { src: "https://picsum.photos/200" }) }) }),
    /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold", children: user.name }),
      /* @__PURE__ */ jsx("h1", { className: "text-xl font-bold", children: user.email }),
      percentage < 100 && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("p", { className: "text-sm py-2", children: "Kelengkapan profil" }),
          /* @__PURE__ */ jsx("progress", { className: "progress transition progress-primary w-full", value: percentage || 0, max: "100" })
        ] }),
        /* @__PURE__ */ jsx(Link, { href: route("profile.edit"), className: "btn btn-outline text-left py-4", children: "Yuk lengkapi profil!!!" })
      ] })
    ] })
  ] });
};
const HeroAkun$1 = HeroAkun;
const MenuAkun = () => {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("ul", { className: "menu bg-base-200 w-full rounded-box text-lg", children: [
      /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(Link, { className: "flex justify-between", children: [
        /* @__PURE__ */ jsx("span", { children: "Bantuan" }),
        /* @__PURE__ */ jsx("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", strokeWidth: "1.5", stroke: "currentColor", className: "w-6 h-6", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M8.25 4.5l7.5 7.5-7.5 7.5" }) })
      ] }) }),
      /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(Link, { className: "flex justify-between", children: [
        /* @__PURE__ */ jsx("span", { children: "Kebijakan Privasi" }),
        /* @__PURE__ */ jsx("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", strokeWidth: "1.5", stroke: "currentColor", className: "w-6 h-6", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M8.25 4.5l7.5 7.5-7.5 7.5" }) })
      ] }) }),
      /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(Link, { className: "flex justify-between", children: [
        /* @__PURE__ */ jsx("span", { children: "Syarat" }),
        /* @__PURE__ */ jsx("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", strokeWidth: "1.5", stroke: "currentColor", className: "w-6 h-6", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M8.25 4.5l7.5 7.5-7.5 7.5" }) })
      ] }) }),
      /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(Link, { className: "flex justify-between", children: [
        /* @__PURE__ */ jsx("span", { children: "Tentang" }),
        /* @__PURE__ */ jsx("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", strokeWidth: "1.5", stroke: "currentColor", className: "w-6 h-6", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M8.25 4.5l7.5 7.5-7.5 7.5" }) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "py-5 md:px-0", children: /* @__PURE__ */ jsx(Logout, {}) })
  ] });
};
const MenuAkun$1 = MenuAkun;
function Akun({ auth, percentage }) {
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Akun" }),
        /* @__PURE__ */ jsx(HeroAkun$1, { user: auth.user, percentage }),
        /* @__PURE__ */ jsx("div", { className: "divider" }),
        /* @__PURE__ */ jsx(MenuAkun$1, {})
      ]
    }
  );
}
export {
  Akun as default
};
