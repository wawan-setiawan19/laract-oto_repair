import { a as jsx, j as jsxs, F as Fragment } from "../ssr.js";
import { P as PieChartComponent, B as BarChartComponent } from "./PieChartComponent-55de6194.js";
import "react";
import { Chart, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from "chart.js";
import { Line } from "react-chartjs-2";
import html2canvas from "html2canvas";
import { jsPDF } from "jspdf";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react";
import "@inertiajs/react/server";
Chart.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);
const LineChartComponent = ({ label, value, title }) => {
  const dataOlah = {
    labels: label,
    datasets: [
      {
        label: title,
        data: value,
        backgroundColor: [
          "rgba(255, 99, 132, 0.2)"
        ],
        borderWidth: 1
      }
    ]
  };
  return /* @__PURE__ */ jsx(Line, { data: dataOlah });
};
const printDocument = () => {
  const input = document.getElementById("printDocument");
  html2canvas(input).then((canvas) => {
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF({
      orientation: "landscape",
      compress: true,
      format: "legal"
    });
    pdf.addImage(imgData, "JPEG", 0, 0);
    pdf.stream();
  });
};
const VisualisasiData = ({ dataLayanan }) => {
  const label = dataLayanan.map((data) => data.kategori);
  const value = dataLayanan.map((data) => data.count);
  let total = 0;
  dataLayanan.map((data) => total += data.count);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("div", { className: "card-actions w-1/4 mb-3 justify-center align-bottom", children: /* @__PURE__ */ jsx("button", { className: "w-full btn btn-primary", onClick: printDocument, children: "Print" }) }),
    /* @__PURE__ */ jsxs("div", { id: "printDocument", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-3xl", children: "Report" }),
      /* @__PURE__ */ jsx("div", { className: "card w-96 md-3", children: /* @__PURE__ */ jsxs("div", { className: "card-body", children: [
        /* @__PURE__ */ jsx("h2", { className: "card-title", children: "Total Layanan Kami" }),
        /* @__PURE__ */ jsx("p", { children: total })
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap", children: [
        /* @__PURE__ */ jsxs("div", { className: "card w-full md:w-1/2 lg:w-1/3 p-4", children: [
          /* @__PURE__ */ jsx("h2", { className: "card-title text-2xl w-2/3", children: "Persentase Layanan" }),
          /* @__PURE__ */ jsx(PieChartComponent, { label, value, title: "Layanan" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "card w-full md:w-1/2 lg:w-1/3 p-4", children: [
          /* @__PURE__ */ jsx("h2", { className: "card-title text-2xl w-2/3", children: "Jumlah Layanan" }),
          /* @__PURE__ */ jsx(BarChartComponent, { label, value, data: dataLayanan, title: "Layanan" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "card w-full md:w-1/2 lg:w-1/3 p-4", children: [
          /* @__PURE__ */ jsx("h2", { className: "card-title text-2xl w-2/3", children: "Jumlah Layanan" }),
          /* @__PURE__ */ jsx(LineChartComponent, { label, value, data: dataLayanan, title: "Layanan" })
        ] })
      ] })
    ] })
  ] });
};
export {
  VisualisasiData as default
};
