import { j as jsxs, a as jsx } from "../ssr.js";
import { useRef, useState } from "react";
function filesize(size) {
  const i = Math.floor(Math.log(size) / Math.log(1024));
  return (size / Math.pow(1024, i)).toFixed(2) * 1 + " " + ["B", "kB", "MB", "GB", "TB"][i];
}
const Button = ({ text, onClick }) => /* @__PURE__ */ jsx(
  "button",
  {
    type: "button",
    className: "px-4 py-2 text-xs font-medium text-white bg-gray-600 rounded-sm focus:outline-none hover:bg-gray-700",
    onClick,
    children: text
  }
);
const FileInput = ({ className, name, label, accept, errors = [], onChange }) => {
  const fileInput = useRef();
  const [file, setFile] = useState(null);
  function browse() {
    fileInput.current.click();
  }
  function remove() {
    setFile(null);
    onChange(null);
    fileInput.current.value = null;
  }
  function handleFileChange(e) {
    const file2 = e.target.files[0];
    setFile(file2);
    onChange(file2);
  }
  return /* @__PURE__ */ jsxs("div", { className, children: [
    /* @__PURE__ */ jsxs("div", { className: `border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm form-input p-0 ${errors.length && "error"}`, children: [
      /* @__PURE__ */ jsx(
        "input",
        {
          id: name,
          ref: fileInput,
          accept,
          type: "file",
          className: "hidden",
          onChange: handleFileChange
        }
      ),
      !file && /* @__PURE__ */ jsx(Button, { text: "Browse", onClick: browse }),
      file && /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between p-2", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-10/12", children: [
          /* @__PURE__ */ jsx("div", { className: "break-words", children: file.name }),
          /* @__PURE__ */ jsxs("span", { className: "ml-1 text-xs text-gray-600", children: [
            "(",
            filesize(file.size),
            ")"
          ] })
        ] }),
        /* @__PURE__ */ jsx(Button, { text: "Remove", onClick: remove })
      ] })
    ] }),
    errors.length > 0 && /* @__PURE__ */ jsx("div", { className: "form-error", children: errors })
  ] });
};
export {
  FileInput as F
};
