import { j as jsxs, a as jsx } from "../ssr.js";
import { A as Authenticated } from "./AuthenticatedLayout-f0c73b1f.js";
import { Head } from "@inertiajs/react";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "./NavBar-c2f6766d.js";
import "react";
function Bengkel({ auth, bengkels, assetPath }) {
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 leading-tight", children: "Bengkel" }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Bengkel" }),
        /* @__PURE__ */ jsx("div", { className: "flex flex-col h-fit content-between", children: /* @__PURE__ */ jsx("h2", { className: "card-title text-3xl w-2/3", children: "Data Bengkel" }) })
      ]
    }
  );
}
export {
  Bengkel as default
};
